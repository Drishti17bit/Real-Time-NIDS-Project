import platform
import threading
from sniffer import start_sniffer
from state import state

if platform.system() == "Linux":
    # Docker mode (no GUI)
    print("Running in CLI mode (Docker)")
    start_sniffer()

else:
    # Windows mode (GUI)
    from dashboard_gui import SnifferGUI

    def main():
        gui = SnifferGUI()
        state.gui = gui

        thread = threading.Thread(target=start_sniffer, daemon=True)
        thread.start()

        gui.run()

    if __name__ == "__main__":
        main()