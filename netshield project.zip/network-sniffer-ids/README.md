# Python Network IDS – MITM & ARP Spoof Detection

A Python-based Network Intrusion Detection System (IDS) that inspects local network traffic in real time to detect cyber attacks such as ARP Cache Poisoning, Man-in-the-Middle (MITM) attacks, and TCP Port Scans.

---

## Features

- **Real-Time Packet Sniffing**: Promiscuous mode capture using Scapy and Npcap.
- **ARP Spoof Detection**: Identifies unsolicited ARP replies and IP-to-MAC mapping discrepancies.
- **MITM Attack Detection**: Dynamic default gateway discovery and rogue MAC alerting.
- **Port Scan & Anomaly Detection**: Tracks TCP SYN packets to identify port sweeps, and flags high-port UDP anomalies.
- **Interactive GUI Dashboard**: Real-time stats, alert counters, and timestamped event feed built with Tkinter.
- **Built-in Attack Simulation Demo**: One-click live demonstration of attacks for presentations and evaluations without requiring a second machine.
- **Persistent Logging**: Stores incident history in `logs/alerts.log`.

---

## Technologies Used

- **Python 3.10+**
- **Scapy** (Network packet manipulation and analysis)
- **Tkinter** (Desktop graphical user interface)
- **Npcap** (Windows packet capture driver)

---

## How to Run Locally (Windows)

### Method 1: One-Click (Recommended)
Double-click **`run_ids.bat`** in the project folder and click **"Yes"** to grant Administrator permission.

### Method 2: Command Line
1. Open **PowerShell** or **Command Prompt** as **Administrator**.
2. Install dependencies (if not already installed):
   ```bash
   pip install -r requirements.txt
   ```
3. Run the application:
   ```bash
   python main.py
   ```
4. Press **Enter** to choose the auto-detected active network interface.

---

## NetShield Web Dashboard

A browser-based dashboard is available in `web_dashboard.py`. It reads the existing `state.py` counters and `logs/alerts.log` and exposes recent events through a local API.

1. Open PowerShell / Command Prompt in this project folder.
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Start the dashboard:
   ```bash
   python web_dashboard.py
   ```
4. Open `http://127.0.0.1:5000` in your browser.
5. Click **Start monitoring** for real packet capture, or **Run demo** to generate synthetic demo traffic.

**Important:** Run the terminal as Administrator on Windows (or root with the required capture permissions on Linux) for live packet capture. Npcap must be installed on Windows. The demo creates synthetic packets for demonstration and does not represent attacks observed on your network. The web dashboard is intended for local use; it has no login/authentication yet, so do not expose it to the public internet.

## Live Demonstration / Evaluation
To demonstrate attacks during a presentation:
- Simply click the **"⚡ Run Attack Simulation (Demo)"** button on the GUI dashboard.
- Watch live alerts stream into the console and see the counters update.
- See [`PRESENTATION_GUIDE.md`](PRESENTATION_GUIDE.md) for a complete step-by-step presentation script and viva answers.