"""
NetShield Web Dashboard
Run with: python web_dashboard.py
For real packet capture, run the terminal as Administrator/root and install requirements.
"""
from __future__ import annotations

import os
import re
import threading
import time
import platform
from datetime import datetime
from pathlib import Path

from flask import Flask, jsonify, request, render_template_string

from state import state

ROOT = Path(__file__).resolve().parent
LOG_PATH = ROOT / "logs" / "alerts.log"
app = Flask(__name__)

capture_lock = threading.Lock()
capture_thread = None
capture_stop = threading.Event()
capture_status = {"running": False, "mode": "stopped", "message": "Monitoring is stopped", "interface": None}
started_at = None

PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>NetShield | Network Security</title>
<style>
:root{--bg:#F5F9FC;--panel:#FFFFFF;--panel2:#D9E8F3;--line:#D4DEE7;--muted:#526A82;--text:#26364A;--cyan:#45647D;--green:#416D57;--red:#A83F3A;--orange:#829DB3;--yellow:#D9E8F3;--navy:#26364A;--sage:#829DB3;--sage-light:#D9E8F3;--buttermilk:#D9E8F3;--shadow:0 8px 24px rgba(38,54,74,.08)}
*{box-sizing:border-box}body{margin:0;background:var(--bg);font:15px/1.6 Inter,Segoe UI,Arial,sans-serif;color:var(--text)}
button,input,select{font:inherit}button{border:1px solid var(--line);border-radius:9px;padding:10px 13px;background:var(--buttermilk);color:#000000;cursor:pointer;font-weight:650;transition:background .15s,border-color .15s,transform .15s}button:hover{background:#E6D6A8;border-color:#A9A083}button.primary{background:var(--buttermilk);border-color:#A9A083;color:#000000}button.primary:hover{background:#E6D6A8}button.danger{background:#E6C1B8;border-color:#9F2929;color:#000000}button:disabled{opacity:.45;cursor:not-allowed}
.shell{display:grid;grid-template-columns:220px minmax(0,1fr);width:100%;min-height:100vh}.side{border-right:1px solid var(--line);background:var(--buttermilk);padding:24px 16px;color:#000000}.brand{display:flex;gap:10px;align-items:center;font-size:20px;font-weight:800;letter-spacing:.2px;color:#FFFFFF}.logo{display:grid;place-items:center;background:var(--buttermilk);border:1px solid #B87550;color:#29231F;width:39px;height:39px;border-radius:11px;font-size:20px}.tag{color:#3F4434;font-size:12px;letter-spacing:1.5px;margin:28px 10px 10px}.nav{display:flex;gap:10px;padding:11px 12px;border-radius:9px;color:#000000;margin:3px 0;transition:background .15s}.nav.active{background:#E8D6A8;color:#29231F;font-weight:750}.side-note{margin-top:36px;padding:14px;background:#E2BFA5;border:1px solid #80604D;border-radius:12px;color:#29231F;font-size:12px}.side-note strong{color:#000000;display:block;margin-bottom:5px}
main{padding:28px 32px;width:100%;max-width:none;min-width:0;margin:0}.top{display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:24px}.eyebrow{color:#426B58;font-size:12px;letter-spacing:1.7px;font-weight:800}.top h1{margin:4px 0 3px;font-size:28px;letter-spacing:-.7px;color:var(--navy)}.sub{color:var(--muted)}.actions{display:flex;gap:8px;flex-wrap:wrap}.status{display:inline-flex;align-items:center;gap:8px;padding:7px 10px;border:1px solid var(--line);border-radius:99px;color:#59604A;background:#3F4434;font-size:12px;margin-bottom:10px}.dot{width:8px;height:8px;border-radius:50%;background:#B8B09F}.dot.live{background:var(--green);box-shadow:0 0 0 3px #83A06B1C}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;width:100%}.card{background:var(--panel);border:1px solid var(--line);border-radius:13px;padding:20px;min-width:0;box-shadow:var(--shadow)}.metric-label{font-size:13px;color:var(--muted);display:flex;justify-content:space-between;gap:8px}.metric{font-size:30px;font-weight:780;letter-spacing:-.7px;margin:12px 0 4px;color:var(--navy)}.hint{font-size:12px;color:#59604A}.cyan{color:#63734B}.red{color:var(--red)}.orange{color:var(--orange)}.yellow{color:var(--yellow)}.green{color:var(--green)}
.row2{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(300px,1fr);gap:18px;margin-top:18px;width:100%}.card-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:15px}.card h2{font-size:16px;margin:0;color:var(--navy)}.pill{border:1px solid var(--line);background:var(--buttermilk);border-radius:99px;padding:4px 8px;color:var(--muted);font-size:11px}.chart{height:270px;position:relative}.chart svg{width:100%;height:100%;overflow:visible}.gridline{stroke:#E8DDCB;stroke-width:1;stroke-dasharray:3 5}.chart-label{fill:#000000;font-size:12px}.line{fill:none;stroke:#63734B;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round}.area{fill:url(#fade)}.bars{display:flex;gap:9px;align-items:end;height:155px;padding:10px 4px 0}.bar-wrap{flex:1;display:flex;flex-direction:column;align-items:center;gap:8px;height:100%;justify-content:end}.bar{width:min(30px,70%);border-radius:5px 5px 2px 2px;background:var(--buttermilk);min-height:3px}.bar-label{font-size:12px;color:#59604A}
.row3{display:grid;grid-template-columns:minmax(0,1.7fr) minmax(300px,1fr);gap:18px;margin-top:18px;width:100%}.filters{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.filters input,.filters select{background:var(--buttermilk);color:#000000;border:1px solid var(--line);border-radius:8px;padding:8px 9px;max-width:100%}
.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;min-width:580px}th{text-align:left;color:#59604A;font-size:11px;letter-spacing:1px;font-weight:750;padding:10px 8px;border-bottom:1px solid var(--line)}td{padding:13px 8px;border-bottom:1px solid #E8DDCB;font-size:13px;color:#3F4434}tbody tr:hover{background:#E9D9C8}tbody tr:last-child td{border-bottom:0}.severity{display:inline-block;border-radius:6px;padding:5px 8px;font-size:11px;font-weight:800;letter-spacing:.4px}.CRITICAL{color:#000000;background:#E6C1B8}.HIGH{color:#B85C38;background:#F3E3A2}.MEDIUM{color:#9B7B36;background:#F3E3A2}.LOW{color:#416D57;background:#E9D9C8}.INFO{color:#B85C38;background:#F4EFE6}.SIMULATION{color:#63734B;background:#3F4434}.empty{text-align:center;color:var(--muted);padding:25px}.event-list{display:flex;flex-direction:column;gap:10px}.event{display:grid;grid-template-columns:10px minmax(0,1fr);gap:10px;padding:10px 0;border-bottom:1px solid #E8DDCB}.event:last-child{border:0}.event-dot{width:8px;height:8px;border-radius:50%;background:var(--orange);margin-top:5px}.event p{margin:0;font-size:13px;color:#3F4434;overflow-wrap:anywhere}.event small{display:block;color:#59604A;font-size:11px;margin-top:4px}.footer{color:#59604A;font-size:11px;margin-top:20px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}.notice{display:none;margin:0 0 14px;padding:10px 12px;border:1px solid #E8DDCB;background:#FFF9F0;color:#9B5C32;border-radius:9px}.notice.show{display:block}
@media(max-width:1100px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}.shell{grid-template-columns:200px minmax(0,1fr)}main{padding:22px}.row2,.row3{grid-template-columns:minmax(0,1fr)}}
@media(max-width:700px){.shell{display:block}.side{display:none}main{padding:16px}.top{align-items:flex-start;flex-direction:column}.top h1{font-size:24px}.grid{grid-template-columns:minmax(0,1fr);gap:9px}.card{padding:14px}.metric{font-size:25px}.actions{width:100%}.actions button{flex:1}.row2,.row3{grid-template-columns:minmax(0,1fr);gap:9px}.filters input{width:100%}}

/* NetShield charcoal + lime theme overrides */
body{background:#F5F9FC;color:#26364A}
.side{background:#526A82;color:#FFFFFF;border-right-color:#45647D}
.brand,.nav,.side-note strong{color:#FFFFFF}
.logo{background:#D9E8F3;border-color:#829DB3;color:#26364A}
.tag{color:#D9E8F3}
.nav.active{background:#D9E8F3;color:#26364A;font-weight:750}
.side-note{background:#D9E8F3;border-color:#829DB3;color:#26364A}
.side-note strong{color:#26364A}
main{background:#F5F9FC;color:#26364A}
.top h1{color:#26364A}
.eyebrow{color:#526A82}
.sub,.footer{color:#526A82}
.status{background:#D9E8F3;color:#26364A;border-color:#829DB3}
.card{background:#FFFFFF;color:#26364A;border-color:#D4DEE7;box-shadow:0 8px 24px rgba(38,54,74,.06)}
.metric-label,.metric,.card h2,.hint,.bar-label,.empty{color:#26364A}
.chart-label{fill:#26364A}
.gridline{stroke:#D4DEE7}
.line{stroke:#45647D}
.bar{background:#829DB3}
.pill{background:#D9E8F3;color:#26364A;border-color:#829DB3}
.filters input,.filters select{background:#FFFFFF;color:#26364A;border-color:#D4DEE7}
th{color:#526A82;border-bottom-color:#D4DEE7}
td{color:#26364A;border-bottom-color:#D4DEE7}
tbody tr:hover{background:#F0F6FA}
.event p{color:#26364A}.event small{color:#526A82}
.event{border-bottom-color:#D4DEE7}
button{background:#D9E8F3;color:#26364A;border-color:#829DB3}
button:hover,button.primary:hover{background:#C4D9E9;border-color:#526A82}
button.primary{background:#D9E8F3;color:#26364A;border-color:#829DB3}
.notice{border-color:#D4DEE7;background:#F0F6FA;color:#26364A}
</style></head>
<body><div class="shell">
<aside class="side"><div class="brand"><div class="logo">⬡</div><div>NetShield<div style="font-size:10px;color:#D9E8F3;font-weight:500;letter-spacing:1.4px">NETWORK DEFENSE</div></div></div>
<div class="tag">WORKSPACE</div><div class="nav active">◈ &nbsp; Security overview</div><div class="nav">⌁ &nbsp; Network activity</div><div class="nav">⚑ &nbsp; Threat incidents</div><div class="nav">▤ &nbsp; Event history</div>
<div class="side-note"><strong>Protection status</strong><span id="sideStatus">Monitoring is stopped</span><div style="margin-top:10px;color:#B85C38">● Local IDS engine</div></div>
<div class="side-note"><strong>Privacy by design</strong>Network events are processed by this local application. Do not expose the dashboard publicly without adding authentication.</div>
</aside>
<main>
<div class="top"><div><div class="eyebrow">SECURITY OPERATIONS / OVERVIEW</div><h1>Network security dashboard</h1><div class="sub">Monitor traffic, inspect alerts, and review suspicious activity.</div></div><div class="actions"><button id="startBtn" class="primary" onclick="startMonitoring()">Start monitoring</button><button id="stopBtn" onclick="stopMonitoring()" disabled>Stop</button><button onclick="runDemo()">Run demo</button></div></div>
<div class="status"><span class="dot" id="statusDot"></span><span id="statusText">Checking engine status…</span></div>
<div id="notice" class="notice"></div>
<section class="grid">
<div class="card"><div class="metric-label">PACKETS INSPECTED <span class="cyan">↗</span></div><div class="metric" id="packets">0</div><div class="hint">Observed by this running process</div></div>
<div class="card"><div class="metric-label">ARP SPOOF ALERTS <span class="orange">⚑</span></div><div class="metric orange" id="arp">0</div><div class="hint">IP-to-MAC mapping changes flagged</div></div>
<div class="card"><div class="metric-label">MITM ALERTS <span class="red">⌁</span></div><div class="metric red" id="mitm">0</div><div class="hint">Gateway MAC changes flagged</div></div>
<div class="card"><div class="metric-label">SCAN / ANOMALIES <span class="yellow">⌕</span></div><div class="metric yellow" id="anomalies">0</div><div class="hint">SYN probes, UDP and ICMP events</div></div>
</section>
<section class="row2">
<div class="card"><div class="card-head"><h2>Packet activity</h2><span class="pill" id="chartStatus">Waiting for traffic</span></div><div class="chart"><svg viewBox="0 0 600 200" preserveAspectRatio="none" aria-label="Packet activity chart"><defs><linearGradient id="fade" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#B85C38" stop-opacity=".25"/><stop offset="1" stop-color="#B85C38" stop-opacity="0"/></linearGradient></defs><g id="chartGrid"></g><path id="chartArea" class="area" d=""></path><path id="chartLine" class="line" d=""></path><g id="chartLabels"></g></svg></div><div class="hint">Rolling samples from this dashboard session; not historical throughput.</div></div>
<div class="card"><div class="card-head"><h2>Alert severity</h2><span class="pill">Logged events</span></div><div class="bars" id="severityBars"></div><div class="hint" style="margin-top:12px">Severity is based on the existing detector log labels.</div></div>
</section>
<section class="row3">
<div class="card"><div class="card-head"><h2>Recent incidents</h2><div class="filters"><select id="severityFilter" onchange="renderAlerts()"><option value="ALL">All severity</option><option>CRITICAL</option><option>HIGH</option><option>MEDIUM</option><option>LOW</option><option>INFO</option><option>SIMULATION</option></select><input id="search" placeholder="Search IP or event…" oninput="renderAlerts()"></div></div><div class="table-wrap"><table><thead><tr><th>TIME</th><th>SEVERITY</th><th>EVENT</th></tr></thead><tbody id="alertRows"><tr><td colspan="3" class="empty">No events loaded yet.</td></tr></tbody></table></div></div>
<div class="card"><div class="card-head"><h2>Live event feed</h2><span class="pill" id="eventCount">0 events</span></div><div id="eventFeed" class="event-list"><div class="empty">Waiting for events…</div></div></div>
</section>
<div class="footer"><span>NetShield • NIDS prototype</span><span>Local dashboard • Refreshes automatically</span><span id="lastUpdated">Last updated —</span></div>
</main></div>
<script>
let allAlerts=[], samples=Array(24).fill(0), lastPacketCount=0;
const $=id=>document.getElementById(id);
function showNotice(msg){$('notice').textContent=msg;$('notice').classList.add('show');}
function hideNotice(){$('notice').classList.remove('show');}
async function api(url, options={}){const r=await fetch(url,{headers:{'Content-Type':'application/json'},...options});const data=await r.json();if(!r.ok)throw new Error(data.error||'Request failed');return data;}
async function refresh(){
 try{
  const d=await api('/api/status'); $('packets').textContent=Number(d.stats.packets||0).toLocaleString();$('arp').textContent=d.stats.arp_alerts||0;$('mitm').textContent=d.stats.mitm_alerts||0;$('anomalies').textContent=(d.stats.port_scan_alerts||0)+(d.stats.suspicious_alerts||0);
  $('statusText').textContent=d.capture.message;$('sideStatus').textContent=d.capture.message;$('statusDot').className='dot'+(d.capture.running?' live':'');$('startBtn').disabled=d.capture.running;$('stopBtn').disabled=!d.capture.running;
  if(d.capture.running){$('chartStatus').textContent='Capturing traffic';}else{$('chartStatus').textContent=d.capture.mode==='demo'?'Demo mode':'Capture stopped';}
  if(d.capture.message && d.capture.message.startsWith('ERROR:'))showNotice(d.capture.message); else hideNotice();
  allAlerts=d.alerts||[];renderAlerts();renderSeverity(d.severity||{});renderFeed(allAlerts.slice(-6).reverse());
  const current=Number(d.stats.packets||0);samples.push(Math.max(0,current-lastPacketCount));samples=samples.slice(-24);lastPacketCount=current;renderChart();
  $('lastUpdated').textContent='Last updated '+new Date().toLocaleTimeString();
 }catch(e){showNotice('Dashboard API error: '+e.message);}
}
function renderAlerts(){const sev=$('severityFilter').value,q=$('search').value.toLowerCase();const rows=allAlerts.filter(a=>(sev==='ALL'||a.severity===sev)&&(a.message+' '+a.time).toLowerCase().includes(q)).slice(-80).reverse();$('alertRows').innerHTML=rows.length?rows.map(a=>`<tr><td>${esc(a.time)}</td><td><span class="severity ${a.severity}">${esc(a.severity)}</span></td><td>${esc(a.message)}</td></tr>`).join(''):'<tr><td colspan="3" class="empty">No matching events.</td></tr>';}
function renderFeed(items){$('eventCount').textContent=allAlerts.length+' events';$('eventFeed').innerHTML=items.length?items.map(a=>`<div class="event"><span class="event-dot" style="background:${color(a.severity)}"></span><div><p>${esc(a.message)}</p><small>${esc(a.time)} · ${esc(a.severity)}</small></div></div>`).join(''):'<div class="empty">No events logged yet.</div>';}
function renderSeverity(counts){const keys=['CRITICAL','HIGH','MEDIUM','LOW','INFO','SIMULATION'];const max=Math.max(1,...keys.map(k=>counts[k]||0));$('severityBars').innerHTML=keys.map(k=>`<div class="bar-wrap" title="${k}: ${counts[k]||0}"><div class="bar" style="height:${Math.max(3,(counts[k]||0)/max*100)}%;background:${color(k)}"></div><div class="bar-label">${k==='SIMULATION'?'SIM':k}</div></div>`).join('');}
function renderChart(){const w=600,h=200,top=15,bottom=28,usable=h-top-bottom,max=Math.max(1,...samples),pts=samples.map((v,i)=>[i*(w/(samples.length-1)),top+usable-(v/max)*usable]);const line=pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+','+p[1].toFixed(1)).join(' ');$('chartLine').setAttribute('d',line);$('chartArea').setAttribute('d',line+` L${w},${h-bottom} L0,${h-bottom} Z`);$('chartGrid').innerHTML=[0,1,2,3].map(i=>`<line class="gridline" x1="0" y1="${top+i*usable/3}" x2="${w}" y2="${top+i*usable/3}"/>`).join('');$('chartLabels').innerHTML=[0,1,2,3].map(i=>`<text class="chart-label" x="4" y="${top+i*usable/3-4}">${Math.round(max*(1-i/3))}</text>`).join('');}
function color(s){return ({CRITICAL:'#C86B58',HIGH:'#D6A34D',MEDIUM:'#f4d98a',LOW:'#C58A70',INFO:'#83A06B',SIMULATION:'#E6D6A8'})[s]||'#A9A083'}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function startMonitoring(){hideNotice();try{const d=await api('/api/monitor/start',{method:'POST',body:JSON.stringify({})});showNotice(d.message);await refresh();}catch(e){showNotice(e.message);}}
async function stopMonitoring(){try{const d=await api('/api/monitor/stop',{method:'POST',body:JSON.stringify({})});showNotice(d.message);await refresh();}catch(e){showNotice(e.message);}}
async function runDemo(){hideNotice();try{const d=await api('/api/demo',{method:'POST',body:JSON.stringify({})});showNotice(d.message);await refresh();}catch(e){showNotice(e.message);}}
renderChart();refresh();setInterval(refresh,2000);
</script></body></html>"""

def parse_log():
    if not LOG_PATH.exists():
        return []
    try:
        lines = LOG_PATH.read_text(encoding="utf-8", errors="replace").splitlines()[-1200:]
    except OSError:
        return []
    out = []
    for line in lines:
        m = re.match(r"^\[(.*?)\]\s+\[(CRITICAL|HIGH|MEDIUM|LOW|INFO|SIMULATION)\]\s*(.*)$", line)
        if m:
            out.append({"time": m.group(1), "severity": m.group(2), "message": m.group(3)})
        else:
            # Preserve other log entries, including simulation step messages.
            tm = re.match(r"^\[(.*?)\]\s+(.*)$", line)
            if tm:
                msg = tm.group(2)
                sev_match = re.match(r"\[(CRITICAL|HIGH|MEDIUM|LOW|INFO|SIMULATION)\]\s*(.*)", msg)
                if sev_match:
                    out.append({"time": tm.group(1), "severity": sev_match.group(1), "message": sev_match.group(2)})
                elif "[SIMULATION]" in msg:
                    out.append({"time": tm.group(1), "severity": "SIMULATION", "message": msg.replace("[SIMULATION]", "").strip()})
                else:
                    out.append({"time": tm.group(1), "severity": "INFO", "message": msg})
    return out

def severity_counts(alerts):
    counts = {k: 0 for k in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO", "SIMULATION")}
    for a in alerts:
        counts[a["severity"]] = counts.get(a["severity"], 0) + 1
    return counts

@app.get("/")
def index():
    return render_template_string(PAGE)

@app.get("/api/status")
def status():
    alerts = parse_log()
    with capture_lock:
        capture = dict(capture_status)
    return jsonify({
        "capture": capture,
        "stats": {
            "packets": state.packet_count,
            "arp_alerts": state.arp_alerts,
            "mitm_alerts": state.mitm_alerts,
            "port_scan_alerts": state.port_scan_alerts,
            "suspicious_alerts": state.suspicious_alerts,
        },
        "alerts": alerts[-250:],
        "severity": severity_counts(alerts),
        "server_time": datetime.now().isoformat(timespec="seconds"),
    })

def capture_worker():
    global capture_thread
    try:
        from sniffer import start_sniffer
        start_sniffer(prompt_user=False, stop_event=capture_stop)
        with capture_lock:
            if capture_status["running"]:
                capture_status.update(running=False, mode="stopped", message="Monitoring stopped")
    except Exception as exc:
        with capture_lock:
            capture_status.update(running=False, mode="stopped", message=f"ERROR: {exc}")
    finally:
        with capture_lock:
            if capture_status["mode"] == "live":
                capture_status.update(running=False, mode="stopped", message="Monitoring stopped")

@app.post("/api/monitor/start")
def monitor_start():
    global capture_thread
    with capture_lock:
        if capture_status["running"]:
            return jsonify({"message": "Monitoring is already running"}), 200
        capture_stop.clear()
        capture_status.update(running=True, mode="live", message="Starting live packet capture…", interface=None)
        capture_thread = threading.Thread(target=capture_worker, daemon=True)
        capture_thread.start()
    return jsonify({"message": "Live capture requested. If capture fails, run the server as Administrator/root and verify the capture driver."})

@app.post("/api/monitor/stop")
def monitor_stop():
    capture_stop.set()
    with capture_lock:
        was_running = capture_status["running"]
        capture_status.update(running=False, mode="stopped", message="Monitoring stop requested")
    return jsonify({"message": "Monitoring stop requested" if was_running else "Monitoring is already stopped"})

@app.post("/api/demo")
def demo():
    with capture_lock:
        if capture_status["mode"] == "demo" and capture_status["running"]:
            return jsonify({"message": "Demo simulation is already running"}), 409
        capture_status.update(running=True, mode="demo", message="Running safe synthetic demo events")
    def worker():
        try:
            import simulate_attacks
            simulate_attacks.run_simulation(on_progress=lambda msg: set_capture_message(msg))
            # Simulation runs asynchronously; allow the progress worker to finish.
            time.sleep(5)
        except Exception as exc:
            set_capture_message(f"ERROR: demo failed: {exc}")
        finally:
            with capture_lock:
                if capture_status["mode"] == "demo":
                    capture_status.update(running=False, mode="stopped", message="Demo finished")
    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"message": "Synthetic attack simulation started. These are demo-generated packets, not real network attacks."})

def set_capture_message(message):
    with capture_lock:
        capture_status["message"] = str(message)

@app.get("/api/health")
def health():
    return jsonify({"ok": True, "service": "NetShield", "time": datetime.now().isoformat(timespec="seconds")})

if __name__ == "__main__":
    host = os.environ.get("NETSHIELD_HOST", "127.0.0.1")
    port = int(os.environ.get("NETSHIELD_PORT", "5000"))
    print(f"NetShield dashboard: http://{host}:{port}")
    print("For live capture, use an elevated terminal. Keep the dashboard on localhost unless authentication is configured.")
    app.run(host=host, port=port, debug=False, threaded=True)
