class GlobalState:
    def __init__(self):
        self.gui = None
        self.packet_count = 0
        self.arp_alerts = 0
        self.mitm_alerts = 0
        self.port_scan_alerts = 0
        self.suspicious_alerts = 0

state = GlobalState()