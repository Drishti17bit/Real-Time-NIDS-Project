from scapy.layers.l2 import ARP
from utils import log_alert
from state import state
import subprocess
import re

def get_default_gateway():
    try:
        out = subprocess.check_output('netsh interface ipv4 show addresses', text=True, errors='ignore')
        gateways = re.findall(r'Default Gateway:\s+([\d\.]+)', out)
        if gateways and gateways[0] != "0.0.0.0":
            return gateways[0]
    except Exception:
        pass
    return "192.168.1.1"

gateway_ip = get_default_gateway()
gateway_mac = None

def analyze_for_mitm(packet):

    global gateway_mac

    if not packet.haslayer(ARP):
        return

    arp = packet[ARP]

    ip = arp.psrc
    mac = arp.hwsrc

    if ip == gateway_ip:

        if gateway_mac is None:
            gateway_mac = mac

        elif gateway_mac != mac:
            state.mitm_alerts += 1
            log_alert(f"[CRITICAL] MITM Attack Detected - Gateway MAC changed -> {mac}")